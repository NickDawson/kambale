package tz.co.fishhappy.app.model;

/**
 * Created by Simon on 06-May-17.
 */

public class FavoriteRemoveModel {
}
