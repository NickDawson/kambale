package tz.co.fishhappy.app.model;

/**
 * Created by Simon on 02-May-17.
 */

public class ForgotPasswordResponseModel {
}
