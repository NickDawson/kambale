package tz.co.fishhappy.app.model;

/**
 * Created by Simon on 14-May-17.
 */

public class CartProductRequestModel {

    private int id;
    private int quantity;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
