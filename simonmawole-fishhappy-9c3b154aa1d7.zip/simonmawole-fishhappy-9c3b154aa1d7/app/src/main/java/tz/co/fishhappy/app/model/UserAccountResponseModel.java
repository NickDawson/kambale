package tz.co.fishhappy.app.model;

/**
 * Created by Simon on 04-May-17.
 */

public class UserAccountResponseModel {
}
