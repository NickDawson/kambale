package tz.co.fishhappy.app.model;

/**
 * Created by Simon on 14-May-17.
 */

public class OrderCancelResponse {
}
