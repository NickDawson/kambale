package tz.co.fishhappy.app.model;

import java.util.List;

/**
 * Created by Simon on 14-May-17.
 */

public class OrderModel {

    private List<Orders> orders = null;

    public List<Orders> getOrders() {
        return orders;
    }

    public void setOrders(List<Orders> orders) {
        this.orders = orders;
    }
}
